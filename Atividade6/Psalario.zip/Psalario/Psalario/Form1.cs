﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nome;
            double bruto;
            decimal filhos;
            bool genero;
            bool casado;

            double desconto_inss;
            double desconto_irpf;

            double salario_familia;
            double salario_liquido;

            nome = txtName.Text;
            filhos = numFilhos.Value;
            genero = checkboxM.Checked;
            casado = cbCasado.Checked;

            bool invalid = (!checkboxF.Checked && !checkboxM.Checked) || (numFilhos.Value < 0) || (txtName.Text == "");

            if (Double.TryParse(txtSalario.Text, out bruto) && bruto > 0 && !invalid)
            {
                desconto_inss   = this.calculateINSS(bruto);
                desconto_irpf   = this.calculateIRPF(bruto);
                salario_familia = this.calculateFamilia(filhos, bruto);
                salario_liquido = bruto - desconto_inss - desconto_irpf + salario_familia;

                txtSalarioLiquido.Text = salario_liquido.ToString();

                MessageBox.Show(
                    "Os descontos do salário "
                    + (genero ? "do Sr. " : "da Sra. ") + nome
                    + "\nque é " + (casado ? "casado(a) " : "solteiro(a) ")
                    + "\ne que tem " + filhos.ToString() + " filho(s) sao: "
                    + "\ndesconto INSS: " + desconto_inss.ToString()
                    + "\ndesconto IRPF: " + desconto_irpf.ToString()
                    + "\nenquanto o salário é de: "
                    + salario_liquido
                );

                return;
            }

            MessageBox.Show("Dados Inválidos");

        }

        private double calculateINSS(double bruto)
        {
            double aliquota_inss;

            if (bruto <= 800.47)
            {
                aliquota_inss = 0.0765;
            }
            else if (bruto <= 1050)
            {
                aliquota_inss = 0.0865;
            }
            else if (bruto <= 1400.77)
            {
                aliquota_inss = 0.09;
            }
            else if (bruto < 2801.56)
            {
                aliquota_inss = 0.11;
            }
            else
            {
                aliquota_inss = 0.11;
            }

            txtAliquotaINSS.Text = Convert.ToString(aliquota_inss * 100) + "%";

            return bruto * aliquota_inss;
        }

        private double calculateIRPF(double bruto)
        {
            double aliquota_irpf = 0;

            if (bruto > 1257.12 && bruto < 2512.08)
            {
                aliquota_irpf = 0.15;
            }
            else if (bruto > 2512.08)
            {
                aliquota_irpf = 0.275;
            }

            txtAliquotaIRPF.Text = Convert.ToString(aliquota_irpf * 100) + "%";

            return bruto * aliquota_irpf;
        }

        private double calculateFamilia(decimal filhos, double bruto)
        {
            if (bruto > 654.61)
            {
                return 0;
            }
            else if (bruto > 435.53)
            {
                return 15.74 * (double) filhos;
            }

            txtSalarioFamilia.Text = Convert.ToString(22.33 * (double)filhos);

            return 22.33 * (double) filhos;
        }
    }

    




}
