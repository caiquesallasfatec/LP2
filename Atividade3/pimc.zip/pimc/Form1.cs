namespace pimc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tableLayoutPanel2_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void sair(object sender, EventArgs e)
        {
            Close();
        }

        private void limpar(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtPeso.Clear();

            txtPeso.Focus();
        }

        private void btnResultado_Click(object sender, EventArgs e)
        {
            calcular();
        }

        private void calcular()
        {
            string alturaSemVirgula;
            string pesoSemVirgula;

            double peso;
            double altura;
            double resultado;
            string message;

            alturaSemVirgula = txtAltura.Text.Replace('.', ',');
            pesoSemVirgula = txtPeso.Text.Replace('.', ',');


            if (Double.TryParse(alturaSemVirgula, out altura) && Double.TryParse(pesoSemVirgula, out peso))
            {
                if (peso != 0 && altura != 0)
                {
                    resultado = peso / Math.Pow(altura, 2);

                    if (resultado > 40)
                    {
                        message = "Obesidade M�rbida";
                    }
                    else if (resultado > 30)
                    {
                        message = "Obesidade";
                    }
                    else if (resultado > 25)
                    {
                        message = "Sobrepeso";
                    }
                    else if (resultado > 18.5)
                    {
                        message = "Normal";
                    }
                    else
                    {
                        message = "Magreza";
                    }

                    MessageBox.Show(message);
                    return;
                }
            }

            MessageBox.Show("Valores inv�lidos");
            txtPeso.Focus();
        }

        private void txtAltura_Enter(object sender, EventArgs e)
        {
            calcular();
        }
    }
}