﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    abstract class Empregado
    {
        private int matricula;
        private string nome;
        private DateTime dataDeEntrada;
        private bool homeoffice;

        public int Matricula
        {
            get { return matricula; }
            set { matricula = value; }
        }        

        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }        

        public DateTime DataDeEntrada
        {
            get { return dataDeEntrada; }
            set { dataDeEntrada = value; }
        }        

        public bool Homeoffice
        {
            get { return homeoffice; }
            set { homeoffice = value; }
        }

        public String VerificaHome()
        {
            if (homeoffice == true)
            {
                return "Empregado trabalha em homeoffice";
            }

            return "Empregado não trabalha em homeoffice";
        }

        public virtual int TempoTrabalho()
        {
            TimeSpan span = DateTime.Today.Subtract(DataDeEntrada);

            return (span.Days);
        }

        public abstract double SalarioBruto();

        public Empregado()
        {

        }
    }

}
