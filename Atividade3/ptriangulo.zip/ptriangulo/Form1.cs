using System.Drawing;
using System.Drawing.Drawing2D;

namespace ptriangulo
{    
    public partial class Form1 : Form
    {
        public static Graphics g;


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            g = CreateGraphics();
        }

        private void draw(int L1, int L2, int L3)
        {            
            int a, b, c;

            int[] inputs = { L1, L2, L3 };

            Array.Sort(inputs);

            a = inputs[0];
            b = inputs[1];
            c = inputs[2];                        

            if (a == b)
            {
                drawIsoscelesTriangle(a, c);
            } else if (b == c)
            {
                drawIsoscelesTriangle(b, a);
            } else
            {
                drawScalanoTriangle(a, b, c);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            draw(5, 16, 20);
        }

        private bool isTriangule(int a, int b, int c)
        {
            int[] inputs = { a, b, c };

            int aux = 0;

            for (int i = 0; i < inputs.Length; i++)
            {
                if (Math.Abs(inputs[0] - inputs[1]) > inputs[2] || (inputs[0] + inputs[1]) < inputs[2] )
                {
                    return false;
                }

                aux = inputs[0];

                inputs[0] = inputs[1];
                inputs[1] = inputs[2];
                inputs[2] = aux;
            }

            return true;
        }

        private void checkInputs()
        {
            int L1;
            int L2;
            int L3;            

            if (Int32.TryParse(txtL1.Text, out L1) &&
            Int32.TryParse(txtL2.Text, out L2) &&
            Int32.TryParse(txtL3.Text, out L3))
            {
                if (isTriangule(L1, L2, L3))
                {
                    draw(L1, L2, L3);
                    if (L1 == L2 && L2 == L3)
                    {
                        lblInfo.Text = "Tri�ngulo Equil�tero e is�sceles";
                    } else if (L1 == L2 || L1 == L3 || L2 == L3)
                    {
                        lblInfo.Text = "Tri�ngulo Is�sceles";
                    } else
                    {
                        lblInfo.Text = "Tri�ngulo Escaleno";
                    }

                    return;
                }
                lblInfo.Text = "N�o � um tri�ngulo";
            }
            return;
        }

        private void drawIsoscelesTriangle(int a, int b)
        {
            g.Clear(BackColor);

            Point ponto1;
            Point ponto2;
            Point ponto3;
            Point[] point = { };
            int y, height, width, downLine, sideHeight;

            y = a * 2 + b;
            height = 270;
            width = 568;
            downLine = 300 * b / y;
            int hypotenuse = 300 * a / y;

            if (hypotenuse == downLine / 2)
            {
                sideHeight = hypotenuse;
            } else
            {
                sideHeight = getHeightFromTriangleRectangle(hypotenuse, downLine / 2);
            }


            ponto1 = new Point(width, height);
            ponto2 = new Point(width + downLine / 2, height - sideHeight);
            ponto3 = new Point(width + downLine, height);

            point = new Point[] { ponto1, ponto2, ponto3 };

            g.FillPolygon(Brushes.Black, point);
        }

        private void drawScalanoTriangle(int min, int med, int max)
        {
            g.Clear(BackColor);

            Point ponto1;
            Point ponto2;
            Point ponto3;
            Point[] point = { };
            int y, height, width, downLine, minWidth, sideHeight;

            y = min + med + max;

            height = 270;
            width = 568;

            downLine = 300 * max / y;

            minWidth = min * downLine / (min + med);

            int hypotenuse = 300 * min / y;

            if (hypotenuse == minWidth)
            {
                sideHeight = minWidth;
            } else
            {
                sideHeight = getHeightFromTriangleRectangle(300 * min / y, minWidth);
            }            

            ponto1 = new Point(width, height);
            ponto2 = new Point(width + minWidth, height - sideHeight);
            ponto3 = new Point(width + downLine, height);

            point = new Point[] { ponto1, ponto2, ponto3 };

            g.FillPolygon(Brushes.Black, point);
        }

        private int getHeightFromTriangleRectangle(int hypotenuse, int side)
        {
            return (int) Math.Round(Math.Sqrt(Math.Pow(hypotenuse, 2) - Math.Pow(side, 2)));
        }

        private void tableLayoutPanel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void txtLAoDigitar(object sender, EventArgs e)
        {
            checkInputs();
        }
    }
}