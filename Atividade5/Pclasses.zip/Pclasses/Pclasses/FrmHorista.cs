﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Pclasses
{
    public partial class FrmHorista : Form
    {
        public FrmHorista()
        {
            InitializeComponent();
        }

        private void lblMatricula_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Horista objHorista = new Horista();

            objHorista.Matricula = Int32.Parse(txtMatriculaH.Text);
            objHorista.Nome = txtNameH.Text;
            objHorista.SalarioHora = Double.Parse(txtSalarioH.Text);
            objHorista.NumeroHora = Int32.Parse(txtNumHora.Text);
            objHorista.DataDeEntrada = DateTime.Parse(txtEntradaH.Text);
            objHorista.Homeoffice = rbSH.Checked;

            MessageBox.Show(
                "Nome: " + objHorista.Nome +
                "\nMatricula: " + objHorista.Matricula +
                "\nTempo na empresa: " + objHorista.TempoTrabalho().ToString() + " dias" +
                "\nHoras trabalhadas: " + objHorista.NumeroHora.ToString() +
                "\nSalário: " + objHorista.SalarioBruto().ToString() +
                "\nHome Office: " + objHorista.VerificaHome()
            );
        }
    }
}
