﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class FrmMensalista : Form
    {
        public FrmMensalista()
        {
            InitializeComponent();
        }

        private void FrmMensalista_Leave(object sender, EventArgs e)
        {

        }

        private void FrmMensalista_Load(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tableLayoutPanel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista();

            objMensalista.Matricula = Int32.Parse(txtMatricula.Text);
            objMensalista.Nome = txtName.Text;
            objMensalista.SalarioMensal = Double.Parse(txtSalario.Text  );
            objMensalista.DataDeEntrada = DateTime.Parse(txtEntrada.Text);
            objMensalista.Homeoffice = rbS.Checked;

            MessageBox.Show(
                "Nome: " + objMensalista.Nome + 
                "\nMatricula: " + objMensalista.Matricula + 
                "\nTempo na empresa: " + objMensalista.TempoTrabalho().ToString() + " dias" +
                "\nSalário: " + objMensalista.SalarioBruto().ToString() +
                "\nHome Office: " + objMensalista.VerificaHome()
            );
        }
    }
}
