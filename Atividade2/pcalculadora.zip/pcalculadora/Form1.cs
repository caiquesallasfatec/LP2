namespace pcalculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void close(object sender, EventArgs e)
        {
            Close();
        }

        private void verifyIfNum2IsnullWhenTextIsChanged(object sender, EventArgs e)
        {
            double num2;

            if (Double.TryParse(txtN2.Text, out num2))
            {
                if (num2 == 0.0)
                {
                    btnDiv.Enabled = false;
                    return;
                }
            }

            btnDiv.Enabled = true;
            return;
        }

        private void clean(object sender, EventArgs e)
        {
            txtN1.Text = null;
            txtN2.Text = null;
            txtResultado.Text = null;

            btnDiv.Enabled = true;
        }

        private double verifyInvalidNumber(string num)
        {
            double convertedNum;

            if (Double.TryParse((num), out convertedNum))
            {
                return convertedNum;
            }
           
            return -1;
        }

        private void calculate(string op, double num1, double num2)
        {
            double result;

            switch (op)
            {
                case "+":
                    result = num1 + num2;
                    break;

                case "-":
                    result = num1 - num2;
                    break;

                case "*":
                    result = num1 * num2;
                    break;
                case "/":
                    result = num1 / num2;
                    break;
                default:
                    result = 0;
                    break;
            }

            txtResultado.Text = result.ToString();
        }

        private void sum(object sender, EventArgs e)
        {
            double n1 = verifyInvalidNumber(txtN1.Text);
            double n2 = verifyInvalidNumber(txtN2.Text);

            if (n1 == -1 || n2 == -1) {
                MessageBox.Show("Valores inv�lidos");
                return;
            }

            calculate("+", n1, n2);
        }

        private void sub(object sender, EventArgs e)
        {
            double n1 = verifyInvalidNumber(txtN1.Text);
            double n2 = verifyInvalidNumber(txtN2.Text);

            if (n1 == -1 || n2 == -1) {
                MessageBox.Show("Valores inv�lidos");
                return;
            }

            calculate("-", n1, n2);
        }

        private void times(object sender, EventArgs e)
        {
            double n1 = verifyInvalidNumber(txtN1.Text);
            double n2 = verifyInvalidNumber(txtN2.Text);

            if (n1 == -1 || n2 == -1) {
                MessageBox.Show("Valores inv�lidos");
                return;
            }

            calculate("*", n1, n2);
        }

        private void div(object sender, EventArgs e)
        {
            double n1 = verifyInvalidNumber(txtN1.Text);
            double n2 = verifyInvalidNumber(txtN2.Text);

            if (n1 == -1 || n2 == -1) {
                MessageBox.Show("Valores inv�lidos");
                return;
            }

            calculate("/", n1, n2);
        }
    }
}